%uUst = u(end, 1)

% Parametry pro bode plot
    wn = 274.2;
    zeta = 0.364697;
    num = [wn^2];
    den = [1, 2*wn*zeta, wn^2];

    % Vytvoreni prenosove funkce
    H = tf(num, den);

G = tf([1],[0.00000694 0.004449 1]);

bode(G, H)

% % subplot(211)
% color = ['b'; 'r'];
% t = 0:0.0001:0.05;
% step(H, t, G,t);
% title('Porovnani odezvy na skok analytickeho a aproximovaneho obrazoveho prenosu')
% legend('Analyticky obrazovy prenos', 'Aproximovany obrazovy prenos')
% grid on;
% xlabel('t (s)'); ylabel('y (t)');
% 
% subplot(212)
% hold on;

t = 0:0.0001:0.1

[y_H, t_H] = step(H, t);
[y_G, t_G] = step(G, t);

% kmitoctove charakteristiky
[mag_H, phase_H, w_H] = bode(H);
[mag_G, phase_G, w_G] = bode(G);

% Oprava dimenzi
mag_H = squeeze(mag_H);  % Odstraní přebytečné dimenze
mag_G = squeeze(mag_G);  % Odstraní přebytečné dimenze
phase_H = squeeze(phase_H);  % Odstraní přebytečné dimenze
phase_G = squeeze(phase_G);  % Odstraní přebytečné dimenze

common_w = intersect(w_H, w_G);
mag_H_common = interp1(w_H, mag_H, common_w, 'linear');
mag_G_common = interp1(w_G, mag_G, common_w, 'linear');
phase_H_common = interp1(w_H, phase_H, common_w, 'linear');
phase_G_common = interp1(w_G, phase_G, common_w, 'linear');

% Výpočet chyby v amplitudách a fázových posunech
chyba_mag = abs(mag_H_common - mag_G_common);  % Chyba v amplitudách
chyba_phase = abs(phase_H_common - phase_G_common);  % Chyba ve fázích

% Vypocet IAE a ISE pro amplitudy a fáze
IAE_mag = trapz(common_w, chyba_mag);  % IAE: Integral of Absolute Error pro amplitudy
IAE_phase = trapz(common_w, chyba_phase);  % IAE: Integral of Absolute Error pro faze

ISE_mag = trapz(common_w, (chyba_mag).^2);  % ISE: Integral of Squared Error pro amplitudy
ISE_phase = trapz(common_w, (chyba_phase).^2);  % ISE: Integral of Squared Error pro faze

% Celkovy IAE a ISE 
IAE_total = IAE_mag + IAE_phase;
ISE_total = ISE_mag + ISE_phase;

% Vykresleni absolutni chyby v amplitudach a fazich
figure;
subplot(2, 1, 1);
semilogx(common_w, chyba_mag, 'k')
title(['Absolutní chyba v amplitudách, IAE = ', num2str(IAE_mag, '%.4g'), ', ISE = ', num2str(ISE_mag, '%.4g')])
xlabel('Frekvence (rad/s)'); ylabel('|chyba_amplituda(frekvence)|');
grid on;

subplot(2, 1, 2);
semilogx(common_w, chyba_phase, 'r')
title(['Absolutní chyba ve fázích, IAE = ', num2str(IAE_phase, '%.4g'), ', ISE = ', num2str(ISE_phase, '%.4g')])
xlabel('Frekvence (rad/s)'); ylabel('|chyba_faze(frekvence)|');
grid on;

% Výpis celkových hodnot IAE a ISE
disp(['Celkový IAE (amplitudy + fáze) = ', num2str(IAE_total, '%.4g')]);
disp(['Celkový ISE (amplitudy + fáze) = ', num2str(ISE_total, '%.4g')]);


% chyba = abs(y_H - y_G);
% 
% IAE = sum(chyba) * (t(2) - t(1));  % Priblizný integral
% ISE = sum((y_H - y_G).^2) * (t(2) - t(1));




% 
% plot(t, chyba, 'k')
% title(['Absolutní chyba, IAE = ', num2str(IAE, '%.4g'), ', ISE = ', num2str(ISE, '%.4g')])
% xlabel('t (s)'); ylabel('|chyba(t)|');
% grid on;

% for i = 1:2
%     hPar(:,i) = step(G(i, 1));
%     plot(t, hPar(:,i), color(i));
%     E(1, i) = sum(abs(hPar(:,i)))
%     pause(1);
% end
% grid on;
% legend('puvodni', 'metoda ploch', 'metoda postupne integrace', 'metoda parametrizace impulsni charakteristiky')
% hold off;
% 
% 
% 
% for i = 1:2
%     plot(t, h - hPar(:,i), color(i), 'LineWidth', 1.2); % Absolutní odchylka v čase
%     legends{i} = ['E = ' num2str(E(1, i), '%.3f')];
% end
% title('Odchylky prenosu od puvodniho prenosu');
% xlabel('t (s)'); ylabel('e(t)');
% legend(legends); % Přidání legendy
% hold off;