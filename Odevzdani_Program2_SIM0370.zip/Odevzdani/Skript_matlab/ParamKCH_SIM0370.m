function G=ParamKCH_SIM0370(A, fi, omega)


%
%Funkce ParamKCH je urcena pro vzhodnoceni kmitoctovych charakteristik
%
%Vstupy:    A .. 1, n - amplituda
%           omega .. 1, n - uhlovy kmitocet
%           fi .. 1, n - faze
% Vystup: G - prenos systemu
%Dne 24.3.2025
%---------


figure(1)
set(1, 'Position', [350 400 800 550]);
subplot(211)
semilogx(omega, 20*log10(A));
title('Odhad prubehu odezvy amplitudove charakteristiky')
subplot(212)
semilogx(omega, fi);

resp = questdlg('je dany system proporcionalni ?','Otazka','ano', 'ne', 'Ano');

if strcmp(resp, 'ano') == 1
   b0 = ceil(A(1,1));
   n = length(A);
   %provedeni vypoctu Re a Im u, v
   u = A(1,:).*cos(pi.*fi(1,:)./180);
   v = A(1,:).*sin(pi.*fi(1,:)./180);
   % vypocet momentu M0, M1, M2
   M0 = b0 - (u+v);
   M1 = -omega.*(u-v);
   M2 = omega.^2.*(u+v); 
   
   S11 = sum(M1.*M1);
   S12 = sum(M1.*M2);
   S22 = sum(M2.*M2);
   Sb1 = -sum(M1.*M0);
   Sb2 = -sum(M2.*M0);
   
   S = [S11 S12; S12 S22];
   Sb = [Sb1; Sb2];
   
   a = S\Sb;
   
   %sestaveni prenosu
   G = tf(b0, [a(2) a(1) 1])
   
   %Vypocet odezvy kmitoctovych charakteristik
   [AKK, fiKK, omegaKK]=bode(G, omega);
   AKK2D(1,:) = AKK(1,1,:);
   fiKK2D(1,:) = fiKK(1,1,:);
   
   disp(omega)
   disp(A)
   disp(fi)
   disp(AKK2D)
   disp(fiKK2D)
   %zobrazeni fysledku parametrizac�we
   
    figure(1)
    set(1, 'Position', [350 400 800 550]);
    subplot(211)
    semilogx(omega, 20*log10(A), 'k*', omega, 20*log10(AKK2D), 'r');
    title('Prubeh odezvy amplitudove charakteristiky')
    xlabel('uhlovy kmitocet (s^{-1})'); ylabel('A (db)'); grid on;
    subplot(212)
    semilogx(omega, fi, 'k*', omega, fiKK2D, 'r');
    title('Prubeh odezvy fazove charakteristiky')
    xlabel('uhlovy kmitocet (s^{-1})'); ylabel('faze (�)'); grid on;

    % Parametry pro bode plot
    wn = 274.2;
    zeta = 0.364697;
    num = [wn^2];
    den = [1, 2*wn*zeta, wn^2];

    % Vytvo�en� p�enosov� funkce
    H = tf(num, den);

    % Z�sk�n� dat pro bode plot
    [mag, phase, omega_bode] = bode(H);

    % P�etvo�en� dat do vhodn�ho form�tu pro zobrazen�
    mag_dB = 20*log10(squeeze(mag));  % P�evod magnitude na dB
    phase_deg = squeeze(phase);        % F�ze v stupn�ch

    % Vlo�en� bode plotu na existuj�c� grafy

    % Amplitudov� charakteristika (subplot 1)
    subplot(211)
    hold on;  % Dr�et st�vaj�c� graf
    semilogx(omega_bode, mag_dB, 'b', 'LineWidth', 2);
    legend('Namerene body', 'Vyhodnocena charakteristika metodou nejm. ctvercu', 'Bode plot - analytick� metoda', 'Location', 'Best');
    hold off;

    % F�zov� charakteristika (subplot 2)
    subplot(212)
    hold on;  % Dr�et st�vaj�c� graf
    semilogx(omega_bode, phase_deg, 'b', 'LineWidth', 2);
    legend('Namerene body', 'Vyhodnocena charakteristika metodou nejm. ctvercu', 'Bode plot - analytick� metoda', 'Location', 'Best');
    hold off;
    set(gca, 'XScale', 'log');
   
else
   uiwait(msgbox('Zdrojovy kod je jen pro proporcionalni typ systemu', 'poznamka'))
   close(1)
end


G = NaN;
